var game = new Phaser.Game(1100, 600, Phaser.CANVAS, 'gameDiv');


var background;  
var haha;
var h1,h2,h3,h4;
var x1,x2,x3,x3; 
var next;
var restart;
var life, gameOverText, bestScoreText;
var timeText;
var stateText;
var bg1, bg2, bg3, bg4, bg5, bg6, bg7;
var bounds = 15000;
var playbutton,pausebutton;
 var basicGame=function(){}   
basicGame.prototype={ 

    preload:function(){
        game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
    game.load.image("background","img/lvl6.png")
    game.load.spritesheet("h1","img/h1.png",201,160);
    game.load.spritesheet("x1","img/x1.png",201,160);
    game.load.spritesheet("x3","img/x3.png",201,160);
    game.load.spritesheet("h2","img/h2.png",201,160);
    game.load.spritesheet("x2","img/x2.png",201,160);
    game.load.spritesheet("h3","img/h3.png",201,160);
    game.load.spritesheet("x4","img/x4.png",201,160);
    game.load.spritesheet("h4","img/h4.png",201,160);
    game.load.image("next","img/next.png")
    game.load.image("restart","img/restart.png")
    game.load.image("menus","img/menus.png")
    game.load.image("playbutton","img/play.png");
    game.load.image("pausebutton","img/pause.png");
    game.load.image("bg1","img/m1.png");
    game.load.image("bg2","img/m2.png");
}, 

    create:function(){ 
    game.physics.startSystem(Phaser.Physics.ARCADE);
    timer(25,1000);
     game.add.sprite(0,0,"background");

        bg2 = game.add.tileSprite(0,
            (game.height - game.cache.getImage("bg2").height)-0,
            bounds,
            game.cache.getImage("bg2").height,
            "bg2");


        bg1 = game.add.tileSprite(0,
            (game.height - game.cache.getImage("bg1").height)-0,
            bounds,
            game.cache.getImage("bg1").height,
            "bg1");
    playbutton = game.add.button(250,530,"playbutton",play);
    playbutton.scale.x = .4;
    playbutton.scale.y= .5;
    pausebutton = game.add.button(350,530,"pausebutton",pause);
    pausebutton.scale.x = .4;
    pausebutton.scale.y= .5;
    next = game.add.button(920,40,"next",next);
    next.scale.x= .6;
    next.scale.y= .7;
    restart = game.add.button(100,40,"restart",back);
    restart.scale.x= .6;
    restart.scale.y= .7;
    menus = game.add.button(100,520,"menus",front);
    menus.scale.x= .6;
    menus.scale.y= .7;
    
    x1 = game.add.button(100,150,"x1",wrong1);
    h1 = game.add.button(350,150,"h1",hide1);
    x2 = game.add.button(600,150,"x2",wrong2);
    x3 = game.add.button(850,150,"x3",wrong3);

    h2= game.add.button(100,350,"h2",hide2); 
    x4 = game.add.button(350,350,"x4",wrong4);
    h3 = game.add.button(600,350,"h3",hide3);
    h4 = game.add.button(850,350,"h4",hide4);

    stateText = game.add.text(0,200,"Time: 25",{ font: '170px GOTHIC', style: 'bold', fill: 'yellow' });
    stateText.visible = false;
    timeText = game.add.text(480,100,"Time: 25",{font: '34px ARIAL', fill:"red"});
    life = game.add.text(520,530,'Score: '+getScore(),{fill:"maroon"});
    bestScoreText = game.add.text(520,560,'Best:   '+getScore(),{fill:"maroon"});
   },

    update: function () {
        bg1.tilePosition.x += 3;
       bg2.tilePosition.y += 2.5;
},
}
  var a = 0;
function hide1(){
  {h1.frame=1}
  a = a + 5;
  if(getScore()<=a){
        saveScore(a);
        bestScoreText.text = "Best: "+a;
    }

    life.text = "Score: "+a; 


game._paused=false; 
}

var a = 0;
function hide2(){
  {h2.frame=1}  
  a = a +5;
  if(getScore()<=a){
        saveScore(a);
        bestScoreText.text = "Best: "+a;
    }

    life.text = "Score: "+a; 

game._paused=false;
}

var a = 0;
function hide3(){
  {h3.frame=1}  
  a = a + 5;
  if(getScore()<=a){
        saveScore(a);
        bestScoreText.text = "Best: "+a;
    }

    life.text = "Score: "+a; 

game._paused=false;
}
  

var a = 0;
function hide4(){
  {h4.frame=1}  
  a = a + 5;
  if(getScore()<=a){
        saveScore(a);
        bestScoreText.text = "Best: "+a;
    } 

    life.text = "Score: "+a; 

game._paused=false;
}


 var a = 0;
function wrong1(){
  {x1.frame=1} 
  a = a - 5;
  if(getScore()<=a){
        saveScore(a);
        bestScoreText.text = "Best: "+a;
    } 

    life.text = "Score: "+a; 

game._paused=false;
}

function wrong2(){
  {x2.frame=1} 
  a = a - 5;
  if(getScore()<=a){
        saveScore(a);
        bestScoreText.text = "Best: "+a;
    } 

    life.text = "Score: "+a; 

game._paused=false;
}

function wrong3(){
  {x3.frame=1}
  a = a - 5;
  if(getScore()<=a){
        saveScore(a);
        bestScoreText.text = "Best: "+a;
    } 

    life.text = "Score: "+a;  

game._paused=false;
}

function wrong4(){
  {x4.frame=1}
  a = a - 5;
  if(getScore()<=a){
        saveScore(a);
        bestScoreText.text = "Best: "+a;
    } 

    life.text = "Score: "+a;  

game._paused=false;
}

function pause()
{
                h1.visible = false;
                x1.visible = false;
                x2.visible = false;
                h2.visible = false;

                h3.visible = false;
                x3.visible = false;
                x4.visible = false;
                h4.visible = false;
                bg1.visible = false;
                bg2.visible = false;
                timeText.visible = false;
                next.visible = false;
                bg1.visible = false;
                bg2.visible = false;
}

function play()
{
                h1.visible = true;
                x1.visible = true;
                x2.visible = true;
                h2.visible = true;
                h3.visible = true;
                x3.visible = true;
                x4.visible = true;
                h4.visible = true;
                bg1.visible = true;
                bg2.visible = true;
                timeText.visible = true;
                next.visible = true;
                bg1.visible = true;
                bg2.visible = true;
}
function next ()
{
     window.location.href="lvl7.html";
  {next.frame=0}  
setTimeout(function(){
    
next.frame=0;
game._paused=false;
},50);
}

function back ()
{
     window.location.href="lvl1.html";
  {restart.frame=0}  
setTimeout(function(){
    
restart.frame=0;
game._paused=false;
},50);
}


function front ()
{
     window.location.href="index.html";
  {menus.frame=0}  
setTimeout(function(){
    
menus.frame=0;
game._paused=false;
},50);
}

function timer(initTime,microsec){
            setInterval(function(){
            initTime--;
            if(initTime>=0){ 
                game._paused = false;
                timeText.text = "Time: "+initTime;
            }
            else{
                
                stateText.text=" GAME OVER ";
                stateText.visible = true;
                h1.visible = false;
                x1.visible = false;
                x2.visible = false;
                h2.visible = false;
                h3.visible = false;
                x3.visible = false;
                x4.visible = false;
                h4.visible = false;
                bg1.visible = false;
                bg2.visible = false;
                bg1.visible = false;
                bg2.visible = false
                next.visible = false;
                playbutton.visible = false;
                pausebutton.visible = false;    }
            },microsec);
        }
        function saveScore(Score){
            localStorage.setItem("gameScore",Score);
        }

        function getScore(){
            return (localStorage.getItem("gameScore") == 
              null || localStorage.getItem("gameScore") == "")?0:localStorage.getItem("gameScore");
        }

    game.state.add("mainGame",basicGame,true);
    game.state.start("mainState");