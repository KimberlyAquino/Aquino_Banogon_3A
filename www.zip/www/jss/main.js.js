function clicked () {

	var user = document.getElementById('username')
	var pass = document.getElementById('password')

	var coruser = "justine";
	var corpass = "pogi";

	if(user.value == coruser) {

		if(pass.value == corpass) {


		window.alert("You are logged in as" + user.value);
		window.location.href="next.html";
		
		} else {

			window.alert("Incorrect username or password");
		}

	} else {

			window.alert("Incorrect username or password");

	}
}