var game = new Phaser.Game(1100, 600, Phaser.CANVAS, 'gameDiv');





var basicGame=function(){}

basicGame.prototype={ 

    preload:function(){
        game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
     game.load.image("background","img/soundandepeks.png")
    game.load.image("menus","img/menus.png")
     }, 
 
    create:function(){
   
    game.physics.startSystem(Phaser.Physics.ARCADE);

     game.add.sprite(0,0,"bgnight");
        game.add.sprite(0,0,"background");
         menus = game.add.button(150,520,"menus",front);
        menus.scale.x= .3;
        menus.scale.y= .4;
       

     game.load.audio("bgmusic")
     bgmusic.play();
    },


    update: function () {

},
}

function front ()
{
     window.location.href="index.html";
  {menus.frame=0}  
setTimeout(function(){
    
menus.frame=0;
game._paused=false;
},50);
}

    game.state.add("mainGame",basicGame,true);
    game.state.start("mainState");