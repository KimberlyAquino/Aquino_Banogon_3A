var game = new Phaser.Game(1100, 600, Phaser.CANVAS, 'gameDiv');

var basicGame=function(){} 
basicGame.prototype={

    preload:function(){
    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;

    game.load.image("background","img/jj.png")
    game.load.image("backgrounds","img/KIM.png")
    game.load.image("menus","img/menus.png")
    
  
 
    },

    create:function(){
   

    
     game.physics.startSystem(Phaser.Physics.ARCADE);

     game.add.sprite(0,0,"bgnight");
     game.add.sprite(0,0,"background");
     menus = game.add.button(150,520,"menus",front);
     menus.scale.x= .3;
     menus.scale.y= .4;

         game.add.sprite(550,0,"backgrounds");
         
       

     game.load.audio("bgmusic")
     bgmusic.play();
    },


    update: function () {




        // bg1.tilePosition.x += 3;
        // bg2.tilePosition.x += 2.5;
        // bg3.tilePosition.x += 2;
        // bg4.tilePosition.x += 1.5;
        // bg5.tilePosition.x += 1;
        // bg6.tilePosition.x += .5;
        // ;

},
}

function front ()
{
     window.location.href="index.html";
  {menus.frame=0}  
setTimeout(function(){
    
menus.frame=0;
game._paused=false;
},50);
}

    game.state.add("mainGame",basicGame,true);
    game.state.start("mainState");