var game = new Phaser.Game(1100, 600, Phaser.CANVAS, 'gameDiv');
var background;  
var haha;
var h1,h2,h3,h4;
var x1,x2,x3,x3;
var next;
var restart;
var tips;
var life, gameOverText, bestScoreText;
var bg1, bg2, bg3, bg4, bg5, bg6, bg7;
var bounds = 15000;
var basicGame=function(){}
basicGame.prototype={ 

    preload:function(){
      game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;

    game.load.image("background","img/bg.png")
    
    game.load.image("taguan","img/taguan.png")

    game.load.image("tags","img/3D2.png")

    game.load.image("start","img/start.png")

    game.load.image("tips","img/help.png")

    game.load.image("set","img/setting.png")

    game.load.image("me","img/about.png")

    game.load.audio("bgmusic","music/alive.mp3") 

    game.load.image("bgnight","img/bgnight.png");

    game.load.image("bg2","img/g1.png");
 
    },

    create:function(){
    game.world.setBounds(0,0,bounds,0);
    game.physics.startSystem(Phaser.Physics.ARCADE);
    game.add.sprite(0,0,"bgnight");
    game.add.sprite(0,0,"background");
    bg2 = game.add.tileSprite(0,
            (game.height - game.cache.getImage("bg2").height)-0,
            bounds,
            game.cache.getImage("bg2").height,
            "bg2");
      start = game.add.button(426,250,"start",haha);
      me = game.add.button(450,350,"tips",help);
      me = game.add.button(475,440,"me",dev);
      set = game.add.button(500,510,"set",setting);
      game.add.sprite(170,30,"tags");
 },
   update: function () {
    bg2.tilePosition.x -= 1.5;
       },
}
  function haha ()
{
     window.location.href="lvl1.html";
  {start.frame=0}  
setTimeout(function(){
    
start.frame=0;
game._paused=false;
},50);
}

function help ()
{
     window.location.href="help.html";
  {tips.frame=0}  
setTimeout(function(){
    
tip.frame=0;
game._paused=false;
},50);
}

function dev ()
{
     window.location.href="about.html";
  {me.frame=0}  
setTimeout(function(){
    
me.frame=0;
game._paused=false;
},50);
}

function setting ()
{
     window.location.href="set.html";
  {set.frame=0}  
setTimeout(function(){
    
set.frame=0;
game._paused=false;
},50);
}
   game.state.add("mainGame",basicGame,true);
    game.state.start("mainState");